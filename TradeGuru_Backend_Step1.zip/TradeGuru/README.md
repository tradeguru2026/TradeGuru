# TradeGuru — Backend Step 1

Node.js + Express REST API starter for the existing TradeGuru frontend prototype.

## Run

1. Install Node.js (LTS).
2. Open a terminal inside `backend`.
3. Run:

```bash
npm install
npm start
```

The API will run at `http://localhost:5000`.

## Test

Open `http://localhost:5000/` in a browser. You should see:

```json
{"app":"TradeGuru API","status":"running","version":"1.0.0"}
```

Endpoints:
- GET /api/notifications
- POST /api/notifications
- GET /api/news
- GET /api/watchlist
- POST /api/watchlist
- DELETE /api/watchlist/:id
- GET /api/portfolio
- GET /api/challenge
- POST /api/challenge/start
- POST /api/challenge/trade

This is an in-memory development backend. Data resets when the server restarts. Database and authentication come next.
